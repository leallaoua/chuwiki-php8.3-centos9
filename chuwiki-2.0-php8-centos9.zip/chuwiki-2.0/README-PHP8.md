# ChuWiki 2.0 - adaptation PHP 8.x

Cette archive est une adaptation pragmatique de ChuWiki 2.0 pour PHP 8.x.

## Changements principaux

- Conversion des appels statiques `ChuWiki::...` : les méthodes de `ChuWiki` sont déclarées `static`.
- Remplacement des anciens constructeurs PHP 4/5 par `__construct()`.
- Suppression des constructions incompatibles PHP 8 :
  - `=& new` remplacé par l'affectation objet normale.
  - accès chaîne `$str{0}` remplacé par `$str[0]`.
  - `ereg()` remplacé par `preg_match()`.
  - `create_function()` remplacé par des fonctions anonymes.
  - `preg_replace(... /e ...)` remplacé par `preg_replace_callback()`.
- Compatibilité `get_magic_quotes_gpc()` : appel protégé car la fonction n'existe plus en PHP récent.
- Ajout d'une propriété manquante dans le remplaçant de smileys pour éviter les avertissements PHP 8.2+.

## Installation Linux rapide

```bash
sudo apt install apache2 php libapache2-mod-php
unzip chuwiki-2.0-php8.zip -d /var/www/html/
sudo chown -R www-data:www-data /var/www/html/chuwiki-2.0/pages
sudo find /var/www/html/chuwiki-2.0 -type d -exec chmod 755 {} \;
sudo find /var/www/html/chuwiki-2.0 -type f -exec chmod 644 {} \;
sudo chmod -R 775 /var/www/html/chuwiki-2.0/pages
```

Puis ouvrir :

```text
http://serveur/chuwiki-2.0/
```

## Note Apache

Le fichier `.htaccess` d'origine est conservé. Si les URLs sans `.php` ne fonctionnent pas, activez `AllowOverride All` côté Apache ou mettez dans `configuration.ini` :

```ini
WikiScript = wiki.php
EditScript = edit.php
HistoryScript = history.php
```

Si `PATH_INFO` pose problème selon l'hébergement, vous pouvez aussi tester :

```ini
UsePathInfo = false
```

## Correctif 2026-04-30 pour CentOS Stream 9 / Apache 2.4 / PHP 8.3

Correctifs ajoutés dans cette version :

- correction de l'erreur 500 sur PHP 8.x causée par `implode('', file(...))` quand le fichier `latest-change.txt` n'existe pas ;
- prise en charge des pages existantes stockées en `.wiki` avec un fichier `latest` ;
- chargement fiable des templates de thème dont les fichiers font `require('theme.php')` ;
- lecture plus robuste des URL `wiki.php/Accueil` sous Apache 2.4 ;
- petites protections contre des variables serveur absentes en mode CLI/test.

### Déploiement conseillé sur CentOS Stream 9

```bash
cd /var/www/html
sudo cp -a chuwiki chuwiki.bak.$(date +%F-%H%M)
sudo unzip chuwiki-2.0-php8-centos9-fixed.zip -d /tmp/chuwiki-fixed
sudo rsync -av /tmp/chuwiki-fixed/chuwiki-2.0/ /var/www/html/chuwiki/
sudo chown -R apache:apache /var/www/html/chuwiki/pages
sudo find /var/www/html/chuwiki -type d -exec chmod 755 {} \;
sudo find /var/www/html/chuwiki -type f -exec chmod 644 {} \;
sudo chmod -R 775 /var/www/html/chuwiki/pages
sudo systemctl restart httpd
```

Puis tester :

```text
http://192.168.1.204/chuwiki/wiki.php/Accueil
```
