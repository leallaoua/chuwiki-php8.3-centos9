# ChuWiki 2.0 corrigé pour CentOS 9 Stream / Apache 2.4 / PHP 8.3

Cette archive contient une version corrigée de ChuWiki 2.0 pour fonctionner avec PHP 8.3 et Apache 2.4.

## Corrections incluses

- Compatibilité PHP 8.x sur plusieurs anciens appels PHP.
- Correction de `configuration.ini` pour utiliser explicitement les scripts PHP :

```ini
WikiScript = wiki.php
EditScript = edit.php
HistoryScript = history.php
```

- Correction de la création automatique des nouvelles pages.
  ChuWiki stocke les pages sous cette forme :

```text
pages/NomDePage/latest
pages/NomDePage/AAAAMMJJHHMMSS.gz
```

Avant cette correction, certaines nouvelles pages comme `alpha`, `beta`, `gamma`, etc. pouvaient échouer à l'enregistrement avec :

```text
Impossible d'écrire cette page...
```

## Installation recommandée

Décompresser l'archive dans `/tmp`, puis synchroniser vers Apache :

```bash
cd /tmp
rm -rf chuwiki-2.0
unzip /chemin/vers/chuwiki-2.0-php8-centos9-fixed-v3.zip

rsync -av /tmp/chuwiki-2.0/ /var/www/html/chuwiki/

chown -R apache:apache /var/www/html/chuwiki
find /var/www/html/chuwiki -type d -exec chmod 755 {} \;
find /var/www/html/chuwiki -type f -exec chmod 644 {} \;
chmod -R 775 /var/www/html/chuwiki/pages

systemctl restart httpd
```

## Cas CentOS / SELinux

Sur CentOS 9 Stream, si SELinux est actif, Apache peut lire les fichiers mais refuser d'écrire dans `pages`.

Vérifier :

```bash
getenforce
```

Si le résultat est `Enforcing`, appliquer le contexte d'écriture Apache :

```bash
dnf install -y policycoreutils-python-utils
semanage fcontext -a -t httpd_sys_rw_content_t "/var/www/html/chuwiki/pages(/.*)?"
restorecon -Rv /var/www/html/chuwiki/pages
systemctl restart httpd
```

## Test d'écriture Apache

Pour vérifier que l'utilisateur Apache peut écrire :

```bash
sudo -u apache touch /var/www/html/chuwiki/pages/test_apache
ls -l /var/www/html/chuwiki/pages/test_apache
rm -f /var/www/html/chuwiki/pages/test_apache
```

## URL de test

```text
http://192.168.1.204/chuwiki/wiki.php/Accueil
```

Pour éditer une nouvelle page :

```text
http://192.168.1.204/chuwiki/edit.php/alpha
```

Après sauvegarde, ChuWiki doit créer automatiquement :

```text
/var/www/html/chuwiki/pages/alpha/
```
