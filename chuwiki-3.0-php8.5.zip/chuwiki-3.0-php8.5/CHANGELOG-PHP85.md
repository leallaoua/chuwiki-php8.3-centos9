# Correspondance exhaustive des corrections — 26 octobre 2026

Mise à jour réalisée par **Abdelkrim Mecif** — [mecif@hotmail.com](mailto:mecif@hotmail.com).

| Correction réalisée sur Integria | État dans ce livrable |
|---|---|
| Méthodes `ChuWiki` rendues `public static` | Déjà statiques ; visibilité explicite ajoutée aux 52 méthodes (51 sur la base Integria, une méthode supplémentaire de stockage historique dans cette archive) |
| `error_reporting(E_ALL)` sans `E_STRICT` | Déjà présent, conservé |
| Deux appels `get_magic_quotes_gpc()` protégés par `function_exists` | Déjà présents, conservés |
| Valeur POST absente remplacée par chaîne vide | `$_POST[$strName] ?? ''` déjà présent |
| Échec de `file()` traité avant `implode()` dans `GetLatestDate` | Déjà présent, avec conservation du fallback vers le fichier historique `latest` |
| Deux `create_function` d’échappement des balises remplacés par closures à argument par référence | Déjà présents dans les deux fichiers wiki2xhtml |
| `create_function` utilisant `preg_quote` remplacé par closure | Déjà présent dans la classe de base |
| Constructeur de `CClosestFinder` exécuté sous PHP 8 | `__construct` déjà présent, conservé |
| Constructeur de `CSmileyReplacer` exécuté sous PHP 8 | `__construct` déjà présent, conservé |
| Propriété `CClosestFinder::$m_abSearch` déclarée et initialisée | Déclaration existante complétée avec `array()` |
| Constructeur du moteur de base exécuté sous PHP 8 | `__construct` déjà présent |
| Constructeur Chu exécuté, avec initialisation parent et options Chu | `__construct` et `parent::__construct()` déjà présents ; initialisation de `functions` conservée |
| Conversion `(boolean)` en `(bool)` | Appliquée |
| Conversion `(integer)` en `(int)` | Appliquée |

Les wrappers de constructeurs ajoutés sur Integria ne sont pas dupliqués ici :
la base ZIP utilisait déjà les constructeurs modernes avec leur corps complet.
Le résultat d’initialisation est équivalent. L’occurrence commentée de
`create_function` reste un commentaire sans effet, comme sur Integria.

Les adaptations antérieures du ZIP (stockage `.wiki`, fichier `latest`, chemins,
création des pages, WikiRenderer et autres corrections PHP8) sont conservées.

## Modifications serveur séparées

Mise à jour de remi-release ; restauration des dépôts Remi ; activation de
CodeReady Builder ; passage du module `remi-7.4` à `remi-8.5` ; mise à jour vers
PHP 8.5.12 et extensions ; activation de PHP-FPM au démarrage ; redémarrage puis
rechargements des services. Aucun de ces éléments système n’est embarqué comme
configuration privée ou script de réinstallation automatique dans cette archive.

## Vérifications du livrable

Contrôle structurel de toutes les correspondances ci-dessus, comparaison des
fichiers avec le ZIP source, conservation de chaque fichier d’origine et test
d’intégrité ZIP. La syntaxe PHP reste à vérifier sur PHP 8.5 (workflow inclus).

## Correctif de déploiement : droits du dossier pages

Ajout au README des commandes chown apache:apache et des permissions 755/644
après extraction. Résout le refus d’écriture observé après déploiement sous root.
Sauvegarde validée par Abdelkrim Mecif sur Integria, sans nouvelle erreur dans
les journaux pendant le test. Aucun fichier PHP modifié par ce correctif.

## Harmonisation du nom du livrable

Dossier racine du ZIP renommé en `chuwiki-3.0-php8.5/`, identique au nom
de l’archive sans extension. Chemins, URL et commandes des README harmonisés.
Sauvegarde hors du répertoire web, extraction temporaire unique, conservation
des pages et de la configuration lors des mises à jour, suppression du chmod 775.

## Correction du bloc d’installation rapide

Suppression du bloc Debian/Ubuntu (apt, www-data) au profit des prérequis
CentOS / INTEGRIA et du compte apache. Correction des deux chemins find
restants vers chuwiki-3.0-php8.5. Syntaxe Bash des README vérifiée.
