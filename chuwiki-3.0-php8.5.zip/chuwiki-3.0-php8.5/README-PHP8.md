# ChuWiki 2.0 - adaptation PHP 8.x

Cette archive est une adaptation pragmatique de ChuWiki 2.0 pour PHP 8.x.

## Changements principaux

- Conversion des appels statiques `ChuWiki::...` : les méthodes de `ChuWiki` sont déclarées `static`.
- Remplacement des anciens constructeurs PHP 4/5 par `__construct()`.
- Suppression des constructions incompatibles PHP 8 :
  - `=& new` remplacé par l'affectation objet normale.
  - accès chaîne `$str{0}` remplacé par `$str[0]`.
  - `ereg()` remplacé par `preg_match()`.
  - `create_function()` remplacé par des fonctions anonymes.
  - `preg_replace(... /e ...)` remplacé par `preg_replace_callback()`.
- Compatibilité `get_magic_quotes_gpc()` : appel protégé car la fonction n'existe plus en PHP récent.
- Ajout d'une propriété manquante dans le remplaçant de smileys pour éviter les avertissements PHP 8.2+.

## Installation rapide sur CentOS / INTEGRIA

```bash
# Prérequis : Apache (httpd), PHP 8.5 et PHP-FPM déjà installés.
# Installation neuve uniquement ; pour une mise à jour, voir plus bas.
cd /var/www/html
sudo unzip chuwiki-3.0-php8.5.zip -d /var/www/html/
sudo chown -R apache:apache /var/www/html/chuwiki-3.0-php8.5/pages
sudo find /var/www/html/chuwiki-3.0-php8.5 -type d -exec chmod 755 {} \;
sudo find /var/www/html/chuwiki-3.0-php8.5 -type f -exec chmod 644 {} \;
```

Puis ouvrir :

```text
http://serveur/chuwiki-3.0-php8.5/
```

## Note Apache

Le fichier `.htaccess` d'origine est conservé. Si les URLs sans `.php` ne fonctionnent pas, activez `AllowOverride All` côté Apache ou mettez dans `configuration.ini` :

```ini
WikiScript = wiki.php
EditScript = edit.php
HistoryScript = history.php
```

Si `PATH_INFO` pose problème selon l'hébergement, vous pouvez aussi tester :

```ini
UsePathInfo = false
```

## Correctif 2026-04-30 pour CentOS Stream 9 / Apache 2.4 / PHP 8.3

Correctifs ajoutés dans cette version :

- correction de l'erreur 500 sur PHP 8.x causée par `implode('', file(...))` quand le fichier `latest-change.txt` n'existe pas ;
- prise en charge des pages existantes stockées en `.wiki` avec un fichier `latest` ;
- chargement fiable des templates de thème dont les fichiers font `require('theme.php')` ;
- lecture plus robuste des URL `wiki.php/Accueil` sous Apache 2.4 ;
- petites protections contre des variables serveur absentes en mode CLI/test.

### Déploiement conseillé sur CentOS Stream 9

```bash
cd /var/www/html
# Sauvegarde si le répertoire existe déjà (hors du répertoire web).
if [ -d chuwiki-3.0-php8.5 ]; then
  sudo mkdir -p /var/backups/chuwiki
  sudo cp -a chuwiki-3.0-php8.5 /var/backups/chuwiki/chuwiki-3.0-php8.5.bak.$(date +%F-%H%M%S)
fi

# Extraction temporaire dans un dossier unique.
CHUWIKI_STAGE=$(mktemp -d /tmp/chuwiki-3.0-php8.5.XXXXXX)
sudo unzip /var/www/html/chuwiki-3.0-php8.5.zip -d "$CHUWIKI_STAGE"

if [ -d /var/www/html/chuwiki-3.0-php8.5 ]; then
  # Mise à jour : conserver les pages et la configuration en place.
  sudo rsync -av --exclude='pages/' --exclude='configuration.ini' "$CHUWIKI_STAGE/chuwiki-3.0-php8.5/" /var/www/html/chuwiki-3.0-php8.5/
else
  sudo rsync -av "$CHUWIKI_STAGE/chuwiki-3.0-php8.5/" /var/www/html/chuwiki-3.0-php8.5/
fi
sudo find /var/www/html/chuwiki-3.0-php8.5 -type d -exec chmod 755 {} \;
sudo find /var/www/html/chuwiki-3.0-php8.5 -type f -exec chmod 644 {} \;
sudo chown -R apache:apache /var/www/html/chuwiki-3.0-php8.5/pages
# Aucun redémarrage nécessaire pour les permissions.
# Si du code PHP a été remplacé, contrôler puis recharger PHP-FPM :
sudo php-fpm -t && sudo systemctl reload php-fpm
```

Puis tester :

```text
http://192.168.1.204/chuwiki-3.0-php8.5/wiki.php/Accueil
```
