# ChuWiki 2.0 corrigé pour CentOS 9 Stream / Apache 2.4 / PHP 8.3

Cette archive contient une version corrigée de ChuWiki 2.0 pour fonctionner avec PHP 8.3 et Apache 2.4.

## Corrections incluses

- Compatibilité PHP 8.x sur plusieurs anciens appels PHP.
- Correction de `configuration.ini` pour utiliser explicitement les scripts PHP :

```ini
WikiScript = wiki.php
EditScript = edit.php
HistoryScript = history.php
```

- Correction de la création automatique des nouvelles pages.
  ChuWiki stocke les pages sous cette forme :

```text
pages/NomDePage/latest
pages/NomDePage/AAAAMMJJHHMMSS.gz
```

Avant cette correction, certaines nouvelles pages comme `alpha`, `beta`, `gamma`, etc. pouvaient échouer à l'enregistrement avec :

```text
Impossible d'écrire cette page...
```

## Installation recommandée

Déposer le ZIP dans `/var/www/html`, puis exécuter :

```bash
cd /var/www/html
# Sauvegarde si le répertoire existe déjà (hors du répertoire web).
if [ -d chuwiki-3.0-php8.5 ]; then
  sudo mkdir -p /var/backups/chuwiki
  sudo cp -a chuwiki-3.0-php8.5 /var/backups/chuwiki/chuwiki-3.0-php8.5.bak.$(date +%F-%H%M%S)
fi

# Extraction temporaire dans un dossier unique.
CHUWIKI_STAGE=$(mktemp -d /tmp/chuwiki-3.0-php8.5.XXXXXX)
sudo unzip /var/www/html/chuwiki-3.0-php8.5.zip -d "$CHUWIKI_STAGE"

if [ -d /var/www/html/chuwiki-3.0-php8.5 ]; then
  # Mise à jour : conserver les pages et la configuration en place.
  sudo rsync -av --exclude='pages/' --exclude='configuration.ini' "$CHUWIKI_STAGE/chuwiki-3.0-php8.5/" /var/www/html/chuwiki-3.0-php8.5/
else
  sudo rsync -av "$CHUWIKI_STAGE/chuwiki-3.0-php8.5/" /var/www/html/chuwiki-3.0-php8.5/
fi
sudo find /var/www/html/chuwiki-3.0-php8.5 -type d -exec chmod 755 {} \;
sudo find /var/www/html/chuwiki-3.0-php8.5 -type f -exec chmod 644 {} \;
sudo chown -R apache:apache /var/www/html/chuwiki-3.0-php8.5/pages
# Aucun redémarrage nécessaire pour les permissions.
# Si du code PHP a été remplacé, contrôler puis recharger PHP-FPM :
sudo php-fpm -t && sudo systemctl reload php-fpm
```

## Cas CentOS / SELinux

Sur CentOS 9 Stream, si SELinux est actif, Apache peut lire les fichiers mais refuser d'écrire dans `pages`.

Vérifier :

```bash
getenforce
```

Si le résultat est `Enforcing`, appliquer le contexte d'écriture Apache :

```bash
dnf install -y policycoreutils-python-utils
semanage fcontext -a -t httpd_sys_rw_content_t "/var/www/html/chuwiki-3.0-php8.5/pages(/.*)?"
restorecon -Rv /var/www/html/chuwiki-3.0-php8.5/pages
systemctl restart httpd
```

## Test d'écriture Apache

Pour vérifier que l'utilisateur Apache peut écrire :

```bash
sudo -u apache touch /var/www/html/chuwiki-3.0-php8.5/pages/test_apache
ls -l /var/www/html/chuwiki-3.0-php8.5/pages/test_apache
rm -f /var/www/html/chuwiki-3.0-php8.5/pages/test_apache
```

## URL de test

```text
http://192.168.1.204/chuwiki-3.0-php8.5/wiki.php/Accueil
```

Pour éditer une nouvelle page :

```text
http://192.168.1.204/chuwiki-3.0-php8.5/edit.php/alpha
```

Après sauvegarde, ChuWiki doit créer automatiquement :

```text
/var/www/html/chuwiki-3.0-php8.5/pages/alpha/
```
